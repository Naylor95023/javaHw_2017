package HomeWork_Ch10;

import java.io.Serializable;

public class Mammal implements Serializable {
	public void _smile(){}
}
