package HomeWork_Ch02;

/*
 *�ĤG�� 2.
 *Math.random()���ͯB�I��
*/

public class Question2 {
	public static void main(String[] args) {	
		//�ƭ�
		double one = Math.random();
		double two = Math.random();
		double three = Math.random();
		double four = Math.random();
		double five = Math.random();
		//
		System.out.println("One : " + one);
		System.out.println("Two : " + two);
		System.out.println("Three : " + three);
		System.out.println("Four : " + four);
		System.out.println("Five : " + five);
	}
}
