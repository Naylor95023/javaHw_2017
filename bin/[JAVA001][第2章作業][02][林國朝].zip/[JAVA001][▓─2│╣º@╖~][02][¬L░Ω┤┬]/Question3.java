 package HomeWork_Ch02;

 /*
  *�ĤG�� 3.
  *��έ��n
 */

public class Question3 {
	public static void main(String[] args) {
		//�ƭ�
		float PI = 3.14f;
		float r = 10f;
		//���n
		float area = (float) (PI * Math.pow(r,2));
		//
		System.out.println(area);
	}
}
