package HomeWork_Ch02;

/*
 *�ĤG�� 4.
 *�r��������ƭ�
*/

public class Question4 {
	public static void main(String[] args) {
		//�ŧi�ƭ�
		int char_0 = '0';
		int char_A = 'A';
		int char_a = 'a';
		int char_Chang = '�i';
		int char_Jun = '�g';
		int char_Ya = '��';
		//
		System.out.println("0 : " + char_0);
		System.out.println("A : " + char_A);
		System.out.println("a : " + char_a);
		System.out.println("�i : " + char_Chang);
		System.out.println("�g : " + char_Jun);
		System.out.println("�� : " + char_Ya);
	}
}
