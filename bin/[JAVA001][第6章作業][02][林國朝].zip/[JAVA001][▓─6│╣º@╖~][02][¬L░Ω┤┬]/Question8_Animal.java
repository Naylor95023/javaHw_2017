package HomeWork06;

public class Question8_Animal {

}
