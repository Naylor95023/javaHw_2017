package HomeWork06;

public class Question8_Cat extends Question8_Mammal{

}
