package HomeWork06;

public class Question8_Dog extends Question8_Mammal{

}
