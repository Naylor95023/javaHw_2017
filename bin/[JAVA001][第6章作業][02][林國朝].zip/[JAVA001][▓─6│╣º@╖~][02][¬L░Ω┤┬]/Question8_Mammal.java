package HomeWork06;

public class Question8_Mammal extends Question8_Animal{

}
