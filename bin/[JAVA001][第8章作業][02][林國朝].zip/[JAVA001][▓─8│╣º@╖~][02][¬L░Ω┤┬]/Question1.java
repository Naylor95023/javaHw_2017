package HomeWork_Ch08;

//�q�R�O�C�Ѽ�argsŪ�J�}�C�A����ҥ~�B�z
public class Question1 {
	void _subroutine(String[] array){
		int sum = 0;
		for(int i = 0; i < array.length; i++){
			try{
				sum += Integer.parseInt(array[i]);
			}
			catch(NumberFormatException e){
				//e.printStackTrace();
				System.out.println("�o�{�ҥ~ : " + array[i]);
			}
			finally {
				System.out.println("�B�z���� : " + array[i]);
			}
		}
		System.out.println("Sum = " + sum);
	}
	//main
	public static void main(String[] args) {
		Question1 test = new Question1();
		test._subroutine(args);
	}
}
