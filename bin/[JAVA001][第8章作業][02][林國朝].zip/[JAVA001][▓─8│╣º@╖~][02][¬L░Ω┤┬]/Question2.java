package HomeWork_Ch08;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;

public class Question2 {
	void _method() {
		//�ҥ~�B�z
		try{
			int i = 3 / 0;
			URL urlA = new URL("http://www.seed.net.tw");
			FileInputStream fis = new FileInputStream("c:\\Test.txt");
		} catch (ArithmeticException e2) {
			e2.printStackTrace();
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		Question2 test = new Question2();
		test._method();
	}
}
