package HomeWork_Ch04;

/*
 *���g�@�ӵ{���L�X
 ********
 *******
 ******
 *****
 ****
 ***
 ** 
 */

public class Question9 {
	public static void main(String[] args) {
		for(int i = 0; i < 7; i++){
			for(int j = i; j < 7; j++){
				System.out.print("*");
			}
			System.out.println(" ");
		}
	}
}
