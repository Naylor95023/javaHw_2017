package HomeWork_Ch06;

public class Question8_Cat extends Question8_Mammal{

}
