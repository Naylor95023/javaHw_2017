package HomeWork_Ch06;

public class Question8_Mammal extends Question8_Animal{

}


